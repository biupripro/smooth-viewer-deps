# Bazel Central Registry

When protobuf is released, we want it to be published to the Bazel Central
Registry automatically: <https://registry.bazel.build>

This folder contains configuration files to automate the publish step. See
<https://github.com/bazel-contrib/publish-to-bcr/blob/main/templates/README.md>
for authoritative documentation about these files.
